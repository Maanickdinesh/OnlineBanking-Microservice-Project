package com.example.entity;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    private Long id;
    private int accountNumber;
    private double amount;
    private LocalDateTime timestamp;
    public enum TransactionType {
        DEPOSIT, WITHDRAWAL, TRANSFER
    }
    private TransactionType type;

    public void setType(TransactionType type) {
        this.type = type;
    }
    private int sourceAccountNumber; 
    private int targetAccountNumber;

}
