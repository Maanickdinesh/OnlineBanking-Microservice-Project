package com.example.controller;

import com.example.entity.Transaction;
import com.example.proxy.TransactionServiceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transaction-consumer")
public class TransactionConsumerController {

    @Autowired
    private TransactionServiceProxy transactionServiceProxy;

    private Logger log = LoggerFactory.getLogger(TransactionConsumerController.class);

    @PutMapping("/deposit/{accountNumber}/{amount}")
    public ResponseEntity<String> deposit(@PathVariable int accountNumber, @PathVariable double amount) {
        log.debug("Initiating deposit for account number: " + accountNumber + ", amount: " + amount);
        ResponseEntity<String> response = transactionServiceProxy.deposit(accountNumber, amount);
        log.debug("Deposit response: " + response.getBody());
        return response;
    }

    @PutMapping("/withdraw/{accountNumber}/{amount}")
    public ResponseEntity<String> withdraw(@PathVariable int accountNumber, @PathVariable double amount) {
        log.debug("Initiating withdrawal for account number: " + accountNumber + ", amount: " + amount);
        ResponseEntity<String> response = transactionServiceProxy.withdraw(accountNumber, amount);
        log.debug("Withdrawal response: " + response.getBody());
        return response;
    }

    @PostMapping("/transfer/{sourceAccountNumber}/{targetAccountNumber}/{amount}")
    public ResponseEntity<String> transfer(@PathVariable int sourceAccountNumber, @PathVariable int targetAccountNumber, @PathVariable double amount) {
        log.debug("Initiating transfer from account " + sourceAccountNumber + " to account " + targetAccountNumber + ", amount: " + amount);
        ResponseEntity<String> response = transactionServiceProxy.transfer(sourceAccountNumber, targetAccountNumber, amount);
        log.debug("Transfer response: " + response.getBody());
        return response;
    }

    @GetMapping("/balance/{accountNumber}")
    public ResponseEntity<String> checkBalance(@PathVariable int accountNumber) {
        log.debug("Checking balance for account number: " + accountNumber);
        ResponseEntity<String> response = transactionServiceProxy.checkBalance(accountNumber);
        log.debug("Balance response: " + response.getBody());
        return response;
    }

    @GetMapping("/all-transactions")
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        log.debug("Fetching all transactions");
        ResponseEntity<List<Transaction>> response = transactionServiceProxy.getAllTransactions();
        log.debug("Fetched all transactions: " + response.getBody());
        return response;
    }

    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<Transaction> getTransactionById(@PathVariable Long transactionId) {
        log.debug("Fetching transaction by ID: " + transactionId);
        ResponseEntity<Transaction> response = transactionServiceProxy.getTransactionById(transactionId);
        log.debug("Fetched transaction by ID: " + transactionId + ": " + response.getBody());
        return response;
    }

//    @GetMapping("/transactions-by-account/{accountNumber}")
//    public List<Transaction> getAllTransactionsByAccountNumber(@PathVariable int accountNumber) {
//        log.debug("Fetching all transactions for account number: " + accountNumber);
//        return transactionServiceProxy.getAllTransactionsByAccountNumber(accountNumber);
//    }
}
