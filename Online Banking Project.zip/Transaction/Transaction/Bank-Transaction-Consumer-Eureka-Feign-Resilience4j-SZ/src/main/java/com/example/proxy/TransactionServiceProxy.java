package com.example.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.entity.Transaction;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "transaction-service")
public interface TransactionServiceProxy {

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackDeposit")
	@PutMapping("/transactions/deposit/{accountNumber}/{amount}")
	ResponseEntity<String> deposit(@PathVariable("accountNumber") int accountNumber,
			@PathVariable("amount") double amount);

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackWithdraw")
	@PutMapping("/transactions/withdraw/{accountNumber}/{amount}")
	ResponseEntity<String> withdraw(@PathVariable("accountNumber") int accountNumber,
			@PathVariable("amount") double amount);

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackTransfer")
	@PostMapping("/transactions/transfer/{sourceAccountNumber}/{targetAccountNumber}/{amount}")
	ResponseEntity<String> transfer(@PathVariable("sourceAccountNumber") int sourceAccountNumber,
			@PathVariable("targetAccountNumber") int targetAccountNumber, @PathVariable("amount") double amount);

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackCheckBalance")
	@GetMapping("/transactions/balance/{accountNumber}")
	ResponseEntity<String> checkBalance(@PathVariable("accountNumber") int accountNumber);

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackGetAllTransactions")
	@GetMapping("/transactions/all")
	ResponseEntity<List<Transaction>> getAllTransactions();

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackGetTransactionById")
	@GetMapping("/transactions/{transactionId}")
	ResponseEntity<Transaction> getTransactionById(@PathVariable("transactionId") Long transactionId);

	@Retry(name = "transaction-service")
	@CircuitBreaker(name = "transaction-service", fallbackMethod = "fallbackGetAllTransactionsByAccountNumber")
	@GetMapping("/transactions/account/{accountNumber}")
	List<Transaction> getAllTransactionsByAccountNumber(@PathVariable("accountNumber") int accountNumber);

	default ResponseEntity<String> fallbackDeposit(int accountNumber, double amount, Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Deposit Service is unavailable");
	}

	default ResponseEntity<String> fallbackWithdraw(int accountNumber, double amount, Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Withdraw Service is unavailable");
	}

	default ResponseEntity<String> fallbackTransfer(int sourceAccountNumber, int targetAccountNumber, double amount,
			Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Transfer Service is unavailable");
	}

	default ResponseEntity<String> fallbackCheckBalance(int accountNumber, Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Check Balance Service is unavailable");
	}

	default ResponseEntity<String> fallbackGetAllTransactions(Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The Get All Transactions Service is unavailable");
	}

	default ResponseEntity<String> fallbackGetTransactionById(Long transactionId, Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The Get Transactions By Id Service is unavailable");
	}

	default ResponseEntity<String> fallbackGetAllTransactionsByAccountNumber(int accountNumber, Throwable cause) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The Get Transaction By Account Number Service is unavailable");
	}
}
