package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.entity.Transaction;
import com.example.demo.entity.Transaction.TransactionType;
import com.example.demo.repo.TransactionRepository;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;
    
    @Autowired
    private AccountService accountService;

    // Deposit money to an account
    public void deposit(int accountNumber, double amount) {
        Account account = accountService.depositAmount(accountNumber, amount);

        if (account != null) {
            Transaction depositTransaction = new Transaction();
            depositTransaction.setAccountNumber(accountNumber);
            depositTransaction.setAmount(amount);
            depositTransaction.setTimestamp(LocalDateTime.now());
            depositTransaction.setType(TransactionType.DEPOSIT);
            transactionRepository.save(depositTransaction);
        } else {
            throw new IllegalArgumentException("Deposit failed.");
        }
    }

    // Withdraw money from an account
    public void withdraw(int accountNumber, double amount) {
    	Account account = accountService.withdrawAmount(accountNumber, amount);
    	if (account != null) {
	        Transaction withdrawalTransaction = new Transaction();
	        withdrawalTransaction.setAccountNumber(accountNumber);
	        withdrawalTransaction.setAmount(-amount); // Negative amount for withdrawal
	        withdrawalTransaction.setTimestamp(LocalDateTime.now());
	        withdrawalTransaction.setType(TransactionType.WITHDRAWAL);
	
	        transactionRepository.save(withdrawalTransaction);
    	}else {
            throw new IllegalArgumentException("withdrawal failed.");
        }
    }

    // Transfer money from one account to another
    public void transfer(int sourceAccountNumber, int targetAccountNumber, double amount) {
        // Attempt to withdraw from the source account
        Account sourceAccount = accountService.withdrawAmount(sourceAccountNumber, amount);

        if (sourceAccount != null) {
            // Attempt to deposit into the target account
            Account targetAccount = accountService.depositAmount(targetAccountNumber, amount);

            if (targetAccount != null) {
                // Create transaction records for both source and target accounts
                Transaction sourceTransaction = new Transaction();
                sourceTransaction.setAccountNumber(sourceAccountNumber);
                sourceTransaction.setAmount(-amount); // Negative amount for withdrawal
                sourceTransaction.setTimestamp(LocalDateTime.now());
                sourceTransaction.setType(TransactionType.TRANSFER);
                sourceTransaction.setSourceAccountNumber(sourceAccountNumber);
                sourceTransaction.setTargetAccountNumber(targetAccountNumber);
                
                Transaction targetTransaction = new Transaction();
                targetTransaction.setAccountNumber(targetAccountNumber);
                targetTransaction.setAmount(amount);
                targetTransaction.setTimestamp(LocalDateTime.now());
                targetTransaction.setType(TransactionType.TRANSFER);
                targetTransaction.setSourceAccountNumber(sourceAccountNumber);
                targetTransaction.setTargetAccountNumber(targetAccountNumber);

                // Save both transaction records
                transactionRepository.saveAll(Arrays.asList(sourceTransaction, targetTransaction));
            } else {
                // If deposit to the target account fails, rollback the withdrawal from the source account
                accountService.depositAmount(sourceAccountNumber, amount); // Rollback
                throw new IllegalArgumentException("Transfer failed. Unable to deposit to the target account.");
            }
        } else {
            throw new IllegalArgumentException("Transfer failed. Insufficient balance in the source account.");
        }
    }
    
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public Optional<Transaction> getTransactionById(Long transactionId) {
        return transactionRepository.findById(transactionId);
    }
    
    public List<Transaction> getAllTransactionsByAccountNumber(int accountNumber) {
        return transactionRepository.findByAccountNumber(accountNumber);
    }
}



