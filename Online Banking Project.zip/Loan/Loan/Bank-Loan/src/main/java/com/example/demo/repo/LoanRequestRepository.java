package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.LoanRequest;

public interface LoanRequestRepository extends JpaRepository<LoanRequest, Long> {
	List<LoanRequest> findByStatus(boolean status);

	List<LoanRequest> findByAccountNumber(int accountNumber);

}
