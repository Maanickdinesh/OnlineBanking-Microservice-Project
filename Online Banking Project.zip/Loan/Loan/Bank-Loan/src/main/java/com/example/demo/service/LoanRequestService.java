package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
//import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.entity.LoanRequest;
import com.example.demo.repo.LoanRequestRepository;

@Service
public class LoanRequestService {
	@Autowired
	private LoanRequestRepository loanRequestRepository;

	public LoanRequest createLoanRequest(LoanRequest loanRequest) {
		// Implement logic to create a loan request
		return loanRequestRepository.save(loanRequest);
	}

	public List<LoanRequest> getPendingLoanRequests() {
		return loanRequestRepository.findByStatus(false);
	}

	public List<LoanRequest> getLoanRequestsByAccount(int accountNumber) {
		return loanRequestRepository.findByAccountNumber(accountNumber);
	}

	public void approveLoanRequest(Long requestId) {
		Optional<LoanRequest> loanRequest = loanRequestRepository.findById(requestId);
		if (loanRequest.isPresent()) {
			LoanRequest request = loanRequest.get();
			request.setStatus(true);
			loanRequestRepository.save(request);
		} else {
			// Handle the case when the request with the given ID is not found
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Loan request with ID " + requestId + " not found");
		}
	}
}
