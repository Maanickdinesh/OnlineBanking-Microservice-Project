package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.LoanRequest;
import com.example.demo.service.LoanRequestService;

@RestController
@RequestMapping("/loan-requests")
public class LoanRequestController {
    @Autowired
    private LoanRequestService loanRequestService;

    Logger log = LoggerFactory.getLogger(LoanRequestController.class);

    // Create a loan request
    @PostMapping("/create")
    public ResponseEntity<LoanRequest> createLoanRequest(@RequestBody LoanRequest loanRequest) {
    	log.debug("Creating a loan request");
        LoanRequest createdRequest = loanRequestService.createLoanRequest(loanRequest);
        log.debug("Created loan request: " + createdRequest);
        return ResponseEntity.ok(createdRequest);
    }

    // Get pending loan requests
    @GetMapping("/pending")
    public ResponseEntity<List<LoanRequest>> getPendingLoanRequests() {
    	log.debug("Fetching pending loan requests");
        List<LoanRequest> pendingRequests = loanRequestService.getPendingLoanRequests();
        log.debug("Fetched pending loan requests: " + pendingRequests);
        return ResponseEntity.ok(pendingRequests);
    }	
    
    // Get loan requests by account ID
    @GetMapping("/account/{accountNumber}")
    public ResponseEntity<List<LoanRequest>> getLoanRequestsByAccount(@PathVariable int accountNumber) {
    	log.debug("Fetching loan requests by account number: " + accountNumber);
        List<LoanRequest> requests = loanRequestService.getLoanRequestsByAccount(accountNumber);
        log.debug("Fetched loan requests for account " + accountNumber + ": " +requests);
        return ResponseEntity.ok(requests);
    }

    // Approve a loan request
    @PostMapping("/approve/{requestId}")
    public ResponseEntity<String> approveLoanRequest(@PathVariable Long requestId) {
    	log.debug("Approving loan request with ID: " + requestId);
        loanRequestService.approveLoanRequest(requestId);
        log.debug("Loan request approval response: Loan request approved.");
        return ResponseEntity.ok("Loan request approved.");
    }
}
