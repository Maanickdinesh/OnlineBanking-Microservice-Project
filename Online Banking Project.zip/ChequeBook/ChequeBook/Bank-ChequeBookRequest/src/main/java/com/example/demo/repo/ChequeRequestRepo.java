package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.ChequeRequest;


@Repository
public interface ChequeRequestRepo extends JpaRepository<ChequeRequest, Long> {

	List<ChequeRequest> findByAuthorized(boolean authorized);
    List<ChequeRequest> findByAccountNumber(int accountNumber);
}
