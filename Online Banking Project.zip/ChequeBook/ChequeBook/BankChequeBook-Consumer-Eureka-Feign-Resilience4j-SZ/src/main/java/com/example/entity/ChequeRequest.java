package com.example.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChequeRequest {
	    private Long id;

	    private int accountNumber;
	    private boolean authorized; // Indicates whether the request is authorized or not

}
