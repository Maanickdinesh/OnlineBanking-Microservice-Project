package com.onlinebanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinebankingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
